# System Architecture: Obsidian Pomodoro Timer Plugin

## 1. Overview

This document provides a comprehensive overview of the system architecture for the Obsidian Pomodoro Timer Plugin. The plugin is designed to help users manage their time and stay focused while working in Obsidian, using the Pomodoro Technique. It provides a configurable timer for Pomodoro sessions and breaks, along with logging, notifications, and other features to enhance productivity.

The plugin is built using TypeScript and leverages the Obsidian API for integration with the Obsidian environment. It is designed to be extensible, allowing for the addition of new features and functionality in the future.

## 2. Core Components

The plugin is composed of several core components, each with its own set of responsibilities.

### 2.1. `PomoTimerPlugin` (main.ts)

This is the main plugin class and the entry point for the plugin. It is responsible for:

*   Initializing the plugin and its components.
*   Loading and saving the plugin settings.
*   Adding the ribbon icon and status bar item.
*   Registering the plugin's commands.
*   Creating and managing the `Timer` instance.

### 2.2. `Timer` (timer.ts)

This is the core of the plugin, containing the main logic for the Pomodoro timer. It is responsible for:

*   Managing the timer's state (e.g., running, paused, stopped).
*   Switching between Pomodoro sessions and breaks.
*   Calculating the remaining time.
*   Handling the end of a session or break.
*   Triggering notifications.
*   Logging completed sessions and breaks.
*   Managing the white noise player.

### 2.3. `PomoSettings` and `DEFAULT_SETTINGS` (settings.ts)

This file defines the data structure for the plugin's settings.

*   `PomoSettings`: An interface that defines the shape of the settings object.
*   `DEFAULT_SETTINGS`: An object that provides the default values for all settings.

### 2.4. `PomoSettingTab` (settings.ts)

This class is responsible for creating and managing the plugin's settings UI. It allows users to configure the plugin's behavior, including:

*   Timer durations (Pomodoro, short break, long break).
*   Logging options (e.g., log file name, log to daily note).
*   Notification settings.
*   Appearance settings.
*   Goal settings.

### 2.5. `WhiteNoise` (white_noise.ts)

This class is responsible for playing and stopping the white noise sound. It is controlled by the `Timer` class.

### 2.6. `CustomSessionModal` (custom_session_modal.ts)

This class creates a modal window that allows users to start a custom Pomodoro session with a specific duration for the session and break.

## 3. Key Workflows

This section describes the key user workflows and how the components interact to achieve them.

### 3.1. Starting and Stopping the Timer

1.  The user clicks the ribbon icon or uses a command to start the timer.
2.  The `onRibbonIconClick` method in the `Timer` class is called.
3.  If no timer is running, `startTimer` is called, which in turn calls `startTimerWithConfirm`.
4.  `startTimerWithConfirm` shows a confirmation modal (if enabled) and then calls `setupTimer` to initialize the timer's state.
5.  `setStatusBarText` is called periodically to update the status bar with the remaining time.
6.  When the timer reaches zero, `handleTimerEnd` is called to handle the end of the session.

### 3.2. Logging Sessions and Breaks

1.  When a session or break is completed or quit, the `logPomo` or `logBreak` method in the `Timer` class is called.
2.  These methods construct a log entry string and call `writeLogEntry`.
3.  `writeLogEntry` reads the log file, prepends the new log entry, and then calls `updateLogSummary`.
4.  `updateLogSummary` reads the log file, calculates the total session and break time, and the daily and weekly goal progress, and then prepends a summary to the log file.

### 3.3. Handling Notifications

1.  When a session or break ends, the `handleTimerEnd` method in the `Timer` class is called.
2.  `handleTimerEnd` calls `playNotification` to play a sound and `showSystemNotification` to show a system notification (if enabled).

### 3.4. Managing Settings

1.  The user opens the plugin's settings tab.
2.  The `PomoSettingTab` class creates the settings UI, with controls for each setting.
3.  When the user changes a setting, the corresponding `onChange` callback is triggered, which updates the `plugin.settings` object and calls `plugin.saveSettings()` to persist the changes.

## 4. Data Model

### 4.1. Settings

The plugin's settings are defined by the `PomoSettings` interface in `src/settings.ts`. The settings are stored in the `data.json` file in the plugin's directory.

### 4.2. Log File Format

The log file is a Markdown file that contains a list of completed sessions and breaks. Each log entry is a single line with the following format:

```
[<emoji>] <start_time> - <end_time> (<duration> minutes)
```

The file also contains a summary at the top, with the following format:

```
---
**Total Session Time:** <total_session_time>
**Total Break Time:** <total_break_time>
**Total Time:** <total_time>
---
**Goals**
**Daily:** <daily_progress>/<daily_goal>
**Weekly:** <weekly_progress>/<weekly_goal>
---
```

## 5. Potential for Extension

The current architecture is designed to be extensible, allowing for the addition of new features and functionality in the future. Here are some examples of how the plugin could be extended:

*   **New Logging Formats:** The `writeLogEntry` and `updateLogSummary` functions could be modified to support different log file formats, such as CSV or JSON.
*   **Task Management Integration:** The plugin could be integrated with a task management system (e.g., Obsidian Tasks) to allow users to associate a task with each Pomodoro session.
*   **Advanced Analytics:** The log data could be used to provide more advanced analytics, such as charts and graphs of the user's productivity over time.
*   **Customizable Notifications:** The notification system could be extended to allow users to choose their own notification sounds or to use different notification styles.
*   **Dedicated UI:** A dedicated view could be created to provide a more comprehensive and user-friendly interface for the timer and log.
